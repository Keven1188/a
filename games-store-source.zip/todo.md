# Games Store Frontend - TODO

## Funcionalidades Principais

- [x] Página inicial com catálogo de jogos
- [x] Busca e filtros de produtos (categoria, plataforma, preço)
- [x] Página de detalhes do produto
- [x] Sistema de carrinho de compras
- [x] Página de checkout
- [ ] Sistema de login/registro
- [x] Página de meus pedidos
- [x] Integração com API (endpoints de produtos, pedidos, usuários)

## Componentes UI

- [x] Header com navegação
- [x] Footer
- [x] Card de produto
- [ ] Carrinho suspenso (dropdown)
- [ ] Modal de login
- [x] Tabela de pedidos
- [x] Filtros de busca

## Correções e Melhorias

- [x] Corrigir erro 404 na rota de busca de produto por ID na API
- [ ] Adicionar validação de formulários
- [ ] Melhorar responsividade mobile
- [ ] Adicionar animações e transições

## Documentação

- [x] Guia de instalação e execução
- [ ] Documentação de componentes
- [ ] Instruções de deployment
