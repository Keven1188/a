import { Link } from 'wouter';
import { ShoppingCart, Search, User, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import { useAuth } from '@/contexts/AuthContext';
import { APP_TITLE } from '@/const';
import { useState } from 'react';

function AuthButtons() {
  const { isAuthenticated, user, logout } = useAuth();

  if (isAuthenticated) {
    return (
      <div className="flex items-center gap-2">
        <Link href="/account">
          <Button variant="outline" className="flex items-center gap-2">
            <User className="w-4 h-4" />
            <span className="hidden sm:inline">{user?.nome_completo.split(' ')[0]}</span>
          </Button>
        </Link>
        <Button variant="ghost" onClick={logout}>
          <LogOut className="w-5 h-5" />
        </Button>
      </div>
    );
  }

  return (
    <Link href="/login">
      <Button className="bg-blue-600 hover:bg-blue-700">Login</Button>
    </Link>
  );
}

export default function Header() {
  const { itemCount } = useCart();
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold">GS</span>
            </div>
            <span className="font-bold text-lg hidden sm:inline">{APP_TITLE}</span>
          </Link>

          {/* Search */}
          <div className="flex-1 max-w-md hidden md:flex">
            <div className="relative w-full">
              <input
                type="text"
                placeholder="Buscar jogos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <Search className="absolute right-3 top-2.5 w-5 h-5 text-gray-400" />
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex items-center gap-4">
            <Link href="/products">
              <Button variant="ghost">Catálogo</Button>
            </Link>
            <Link href="/orders">
              <Button variant="ghost">Meus Pedidos</Button>
            </Link>
            <Link href="/cart">
              <Button variant="outline" className="relative">
                <ShoppingCart className="w-5 h-5" />
                {itemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {itemCount}
                  </span>
                )}
              </Button>
            </Link>
            <AuthButtons />
          </nav>
        </div>
      </div>
    </header>
  );
}
