import { useAuth } from '@/contexts/AuthContext';
import { useLocation, Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Plus, Edit, Trash2 } from 'lucide-react';
import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { API_ENDPOINTS } from '@/lib/api';

interface Product {
  id: number;
  nome: string;
  preco: number;
  categoria: string;
  plataforma: string;
  estoque: number;
}

export default function Admin() {
  const { user, isAdmin } = useAuth();
  const [, setLocation] = useLocation();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    nome: '',
    preco: '',
    categoria: '',
    plataforma: '',
    desenvolvedor: '',
    publisher: '',
    descricao: '',
    data_lancamento: '',
    classificacao_etaria: '',
    estoque: '',
  });

  // Verificar se é admin
  useEffect(() => {
    if (!isAdmin) {
      setLocation('/');
      toast.error('Acesso negado. Apenas administradores podem acessar esta página.');
    }
  }, [isAdmin, setLocation]);

  // Carregar produtos
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch(API_ENDPOINTS.PRODUCTS + '?limit=100');
        const data = await response.json();
        if (data.success) {
          setProducts(data.data);
        }
      } catch (error) {
        console.error('Erro ao buscar produtos:', error);
        toast.error('Erro ao carregar produtos');
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const response = await fetch(API_ENDPOINTS.PRODUCTS, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
        },
        body: JSON.stringify({
          ...formData,
          preco: parseFloat(formData.preco),
          estoque: parseInt(formData.estoque),
        }),
      });

      const data = await response.json();

      if (data.success) {
        toast.success('Produto adicionado com sucesso!');
        setFormData({
          nome: '',
          preco: '',
          categoria: '',
          plataforma: '',
          desenvolvedor: '',
          publisher: '',
          descricao: '',
          data_lancamento: '',
          classificacao_etaria: '',
          estoque: '',
        });
        setShowForm(false);
        // Recarregar produtos
        const response = await fetch(API_ENDPOINTS.PRODUCTS + '?limit=100');
        const newData = await response.json();
        if (newData.success) {
          setProducts(newData.data);
        }
      } else {
        toast.error(data.message || 'Erro ao adicionar produto');
      }
    } catch (error) {
      console.error('Erro:', error);
      toast.error('Erro ao conectar com o servidor');
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Tem certeza que deseja deletar este produto?')) return;

    try {
      const response = await fetch(`${API_ENDPOINTS.PRODUCTS}/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
        },
      });

      const data = await response.json();

      if (data.success) {
        toast.success('Produto deletado com sucesso!');
        setProducts(products.filter((p) => p.id !== id));
      } else {
        toast.error(data.message || 'Erro ao deletar produto');
      }
    } catch (error) {
      console.error('Erro:', error);
      toast.error('Erro ao conectar com o servidor');
    }
  };

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <Link href="/">
          <Button variant="outline" className="mb-8">
            <ArrowLeft className="mr-2 w-4 h-4" />
            Voltar
          </Button>
        </Link>

        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Painel Administrativo</h1>
          <p className="text-gray-600">Bem-vindo, {user?.nome_completo}!</p>
        </div>

        {/* Botão para adicionar produto */}
        <div className="mb-8">
          <Button
            size="lg"
            className="bg-blue-600 hover:bg-blue-700"
            onClick={() => setShowForm(!showForm)}
          >
            <Plus className="mr-2 w-5 h-5" />
            {showForm ? 'Cancelar' : 'Adicionar Novo Produto'}
          </Button>
        </div>

        {/* Formulário de Adicionar Produto */}
        {showForm && (
          <div className="bg-white rounded-lg shadow-md p-8 mb-8">
            <h2 className="text-2xl font-bold mb-6">Adicionar Novo Produto</h2>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input
                type="text"
                name="nome"
                placeholder="Nome do Jogo"
                value={formData.nome}
                onChange={handleChange}
                className="col-span-1 md:col-span-2 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />

              <input
                type="number"
                name="preco"
                placeholder="Preço"
                value={formData.preco}
                onChange={handleChange}
                step="0.01"
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />

              <input
                type="number"
                name="estoque"
                placeholder="Estoque"
                value={formData.estoque}
                onChange={handleChange}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />

              <input
                type="text"
                name="categoria"
                placeholder="Categoria"
                value={formData.categoria}
                onChange={handleChange}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />

              <input
                type="text"
                name="plataforma"
                placeholder="Plataforma"
                value={formData.plataforma}
                onChange={handleChange}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />

              <input
                type="text"
                name="desenvolvedor"
                placeholder="Desenvolvedor"
                value={formData.desenvolvedor}
                onChange={handleChange}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />

              <input
                type="text"
                name="publisher"
                placeholder="Publisher"
                value={formData.publisher}
                onChange={handleChange}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />

              <input
                type="date"
                name="data_lancamento"
                value={formData.data_lancamento}
                onChange={handleChange}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />

              <input
                type="text"
                name="classificacao_etaria"
                placeholder="Classificação Etária (ex: 12, 16, 18)"
                value={formData.classificacao_etaria}
                onChange={handleChange}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />

              <textarea
                name="descricao"
                placeholder="Descrição do Jogo"
                value={formData.descricao}
                onChange={handleChange}
                className="col-span-1 md:col-span-2 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 h-24"
                required
              />

              <Button type="submit" className="col-span-1 md:col-span-2 bg-blue-600 hover:bg-blue-700">
                Adicionar Produto
              </Button>
            </form>
          </div>
        )}

        {/* Lista de Produtos */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6 border-b">
            <h2 className="text-2xl font-bold">Produtos ({products.length})</h2>
          </div>

          {loading ? (
            <div className="p-6 text-center">
              <p className="text-gray-600">Carregando produtos...</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-6 py-3 text-left text-sm font-semibold">Nome</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold">Preço</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold">Categoria</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold">Plataforma</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold">Estoque</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {products.map((product) => (
                    <tr key={product.id} className="hover:bg-gray-50 transition">
                      <td className="px-6 py-4 font-medium">{product.nome}</td>
                      <td className="px-6 py-4">R$ {product.preco.toFixed(2)}</td>
                      <td className="px-6 py-4 text-sm">{product.categoria}</td>
                      <td className="px-6 py-4 text-sm">{product.plataforma}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                          product.estoque > 0
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {product.estoque}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleDelete(product.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
