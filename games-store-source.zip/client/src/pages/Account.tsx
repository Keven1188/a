import { useAuth } from '@/contexts/AuthContext';
import { useLocation, Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowLeft, LogOut, Shield } from 'lucide-react';

export default function Account() {
  const { user, logout, isAdmin } = useAuth();
  const [, setLocation] = useLocation();

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-8">
        <p className="text-gray-600">Por favor, faça login para acessar sua conta.</p>
        <Link href="/login">
          <Button className="mt-4">Ir para Login</Button>
        </Link>
      </div>
    );
  }

  const handleLogout = () => {
    logout();
    setLocation('/');
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <Link href="/">
          <Button variant="outline" className="mb-8">
            <ArrowLeft className="mr-2 w-4 h-4" />
            Voltar
          </Button>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-24">
              <div className="text-center mb-6">
                <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold text-2xl">
                    {user.nome_completo.charAt(0).toUpperCase()}
                  </span>
                </div>
                <h2 className="text-xl font-bold">{user.nome_completo}</h2>
                <p className="text-gray-600 text-sm">@{user.username}</p>
                {isAdmin && (
                  <div className="mt-3 inline-flex items-center gap-1 bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-semibold">
                    <Shield className="w-4 h-4" />
                    Administrador
                  </div>
                )}
              </div>

              <div className="space-y-2">
                {isAdmin && (
                  <Link href="/admin">
                    <Button className="w-full bg-purple-600 hover:bg-purple-700">
                      Painel de Admin
                    </Button>
                  </Link>
                )}
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={handleLogout}
                >
                  <LogOut className="mr-2 w-4 h-4" />
                  Sair
                </Button>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md p-8">
              <h1 className="text-3xl font-bold mb-8">Minha Conta</h1>

              {/* Informações Pessoais */}
              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4">Informações Pessoais</h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Nome Completo
                    </label>
                    <p className="text-gray-900 font-medium">{user.nome_completo}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Usuário
                    </label>
                    <p className="text-gray-900 font-medium">@{user.username}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <p className="text-gray-900 font-medium">{user.email}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Tipo de Conta
                    </label>
                    <p className="text-gray-900 font-medium">
                      {isAdmin ? 'Administrador' : 'Cliente'}
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Status
                    </label>
                    <p className={`font-medium ${user.ativo ? 'text-green-600' : 'text-red-600'}`}>
                      {user.ativo ? 'Ativo' : 'Inativo'}
                    </p>
                  </div>
                </div>
              </section>

              {/* Ações */}
              <section className="border-t pt-8">
                <h2 className="text-2xl font-semibold mb-4">Ações</h2>
                <div className="space-y-3">
                  <Button variant="outline" className="w-full">
                    Alterar Senha
                  </Button>
                  <Button variant="outline" className="w-full">
                    Editar Perfil
                  </Button>
                  <Button variant="destructive" className="w-full" onClick={handleLogout}>
                    <LogOut className="mr-2 w-4 h-4" />
                    Sair da Conta
                  </Button>
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
