import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowRight, Gamepad2, Zap, Trophy } from 'lucide-react';
import { useEffect, useState } from 'react';
import { API_ENDPOINTS } from '@/lib/api';
import { toast } from 'sonner';

interface Product {
  id: number;
  nome: string;
  preco: number;
  categoria: string;
  imagem_url?: string;
}

export default function Home() {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch(`${API_ENDPOINTS.PRODUCTS}?limit=6`);
        const data = await response.json();
        if (data.success) {
          setFeaturedProducts(data.data);
        } else {
          console.error('Erro na resposta da API:', data);
        }
      } catch (error) {
        console.error('Erro ao buscar produtos:', error);
        toast.error('Erro ao carregar produtos. Verifique se a API está rodando.');
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Bem-vindo à Games Store
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Descubra os melhores jogos com os preços mais competitivos do mercado. Compre com segurança e aproveite nossas promoções exclusivas.
            </p>
            <div className="flex gap-4">
              <Link href="/products">
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                  Explorar Catálogo
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Button size="lg" variant="outline">
                Saiba Mais
              </Button>
            </div>
          </div>
          <div className="bg-gradient-to-br from-blue-400 to-purple-500 rounded-lg p-8 text-white flex items-center justify-center min-h-96">
            <Gamepad2 className="w-32 h-32 opacity-20" />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-white py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Por que escolher a Games Store?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Entrega Rápida</h3>
              <p className="text-gray-600">Receba seus jogos digitais instantaneamente após a compra.</p>
            </div>
            <div className="text-center">
              <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Trophy className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Melhor Preço</h3>
              <p className="text-gray-600">Garantimos os melhores preços do mercado com promoções exclusivas.</p>
            </div>
            <div className="text-center">
              <div className="bg-purple-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Gamepad2 className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Grande Variedade</h3>
              <p className="text-gray-600">Milhares de jogos de todos os gêneros e plataformas.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold mb-12">Produtos em Destaque</h2>
        {loading ? (
          <div className="text-center py-12">
            <p className="text-gray-600">Carregando produtos...</p>
          </div>
        ) : featuredProducts.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-600 mb-4">Nenhum produto disponível no momento.</p>
            <p className="text-sm text-gray-500">Certifique-se de que a API está rodando em {API_ENDPOINTS.PRODUCTS}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProducts.map((product) => (
              <Link key={product.id} href={`/products/${product.id}`}>
                <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition overflow-hidden cursor-pointer">
                  <div className="bg-gray-200 h-48 flex items-center justify-center">
                    <Gamepad2 className="w-16 h-16 text-gray-400" />
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-lg mb-2 line-clamp-2">{product.nome}</h3>
                    <p className="text-sm text-gray-600 mb-3">{product.categoria}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-2xl font-bold text-blue-600">
                        R$ {product.preco.toFixed(2)}
                      </span>
                      <Button size="sm">Ver Detalhes</Button>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 text-white py-16 mt-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Pronto para começar?</h2>
          <p className="text-lg mb-8 opacity-90">Explore nosso catálogo completo e encontre seus jogos favoritos.</p>
          <Link href="/products">
            <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
              Ir para o Catálogo
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
