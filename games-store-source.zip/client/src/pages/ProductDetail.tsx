import { useRoute, Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Gamepad2, ArrowLeft, ShoppingCart } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useCart } from '@/contexts/CartContext';
import { API_ENDPOINTS } from '@/lib/api';
import { toast } from 'sonner';

interface Product {
  id: number;
  nome: string;
  descricao: string;
  preco: number;
  categoria: string;
  plataforma: string;
  desenvolvedor: string;
  publisher: string;
  data_lancamento: string;
  classificacao_etaria: string;
  estoque: number;
  imagem_url?: string;
}

export default function ProductDetail() {
  const [match, params] = useRoute('/products/:id');
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const { addItem } = useCart();

  useEffect(() => {
    if (!params?.id) return;

    const fetchProduct = async () => {
      try {
        const response = await fetch(API_ENDPOINTS.PRODUCT_BY_ID(parseInt(params.id)));
        const data = await response.json();
        if (data.success) {
          setProduct(data.data);
        } else {
          toast.error('Produto não encontrado');
        }
      } catch (error) {
        console.error('Erro ao buscar produto:', error);
        toast.error('Erro ao carregar produto');
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [params?.id]);

  const handleAddToCart = () => {
    if (product) {
      addItem({
        id: product.id,
        nome: product.nome,
        preco: product.preco,
        quantidade: quantity,
        imagem_url: product.imagem_url,
      });
      toast.success(`${quantity}x ${product.nome} adicionado ao carrinho!`);
      setQuantity(1);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <p className="text-gray-600">Carregando produto...</p>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Link href="/products">
          <Button variant="outline" className="mb-4">
            <ArrowLeft className="mr-2 w-4 h-4" />
            Voltar ao Catálogo
          </Button>
        </Link>
        <p className="text-gray-600">Produto não encontrado.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <Link href="/products">
          <Button variant="outline" className="mb-8">
            <ArrowLeft className="mr-2 w-4 h-4" />
            Voltar ao Catálogo
          </Button>
        </Link>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 bg-white rounded-lg shadow-md p-8">
          {/* Product Image */}
          <div className="flex items-center justify-center bg-gray-100 rounded-lg min-h-96">
            <Gamepad2 className="w-32 h-32 text-gray-400" />
          </div>

          {/* Product Info */}
          <div>
            <div className="mb-6">
              <h1 className="text-3xl font-bold mb-2">{product.nome}</h1>
              <div className="flex gap-2 mb-4">
                <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
                  {product.categoria}
                </span>
                <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                  {product.plataforma}
                </span>
              </div>
            </div>

            {/* Price */}
            <div className="mb-6 pb-6 border-b">
              <p className="text-gray-600 text-sm mb-2">Preço</p>
              <p className="text-4xl font-bold text-blue-600">R$ {product.preco.toFixed(2)}</p>
            </div>

            {/* Description */}
            <div className="mb-6">
              <h3 className="font-semibold text-lg mb-2">Descrição</h3>
              <p className="text-gray-700">{product.descricao}</p>
            </div>

            {/* Details */}
            <div className="mb-6 space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Desenvolvedor:</span>
                <span className="font-medium">{product.desenvolvedor}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Publicadora:</span>
                <span className="font-medium">{product.publisher}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Data de Lançamento:</span>
                <span className="font-medium">
                  {new Date(product.data_lancamento).toLocaleDateString('pt-BR')}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Classificação Etária:</span>
                <span className="font-medium">{product.classificacao_etaria}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Estoque:</span>
                <span className={`font-medium ${product.estoque > 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {product.estoque > 0 ? `${product.estoque} unidades` : 'Fora de estoque'}
                </span>
              </div>
            </div>

            {/* Quantity and Add to Cart */}
            {product.estoque > 0 && (
              <div className="flex gap-4">
                <div className="flex items-center border border-gray-300 rounded-lg">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-4 py-2 hover:bg-gray-100"
                  >
                    -
                  </button>
                  <span className="px-4 py-2 font-semibold">{quantity}</span>
                  <button
                    onClick={() => setQuantity(Math.min(product.estoque, quantity + 1))}
                    className="px-4 py-2 hover:bg-gray-100"
                  >
                    +
                  </button>
                </div>
                <Button
                  size="lg"
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                  onClick={handleAddToCart}
                >
                  <ShoppingCart className="mr-2 w-5 h-5" />
                  Adicionar ao Carrinho
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
