import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Gamepad2, Filter } from 'lucide-react';
import { useEffect, useState } from 'react';
import { API_ENDPOINTS } from '@/lib/api';
import { toast } from 'sonner';

interface Product {
  id: number;
  nome: string;
  preco: number;
  categoria: string;
  plataforma: string;
  imagem_url?: string;
}

interface Category {
  categoria: string;
}

export default function Products() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch products
        const productsResponse = await fetch(`${API_ENDPOINTS.PRODUCTS}?limit=50`);
        const productsData = await productsResponse.json();
        if (productsData.success) {
          setProducts(productsData.data);
        } else {
          toast.error('Erro ao carregar produtos');
        }

        // Fetch categories
        const categoriesResponse = await fetch(API_ENDPOINTS.CATEGORIES);
        const categoriesData = await categoriesResponse.json();
        if (categoriesData.success && Array.isArray(categoriesData.data)) {
          const categoryNames = categoriesData.data.map((cat: Category) => cat.categoria).filter(Boolean);
          setCategories(categoryNames);
        }
      } catch (error) {
        console.error('Erro ao buscar dados:', error);
        toast.error('Erro ao buscar dados. Verifique se a API está rodando.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const filteredProducts = products.filter((product) => {
    const matchesCategory = !selectedCategory || product.categoria === selectedCategory;
    const matchesSearch = !searchTerm || product.nome.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Catálogo de Jogos</h1>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar - Filtros */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-24">
              <div className="flex items-center gap-2 mb-6">
                <Filter className="w-5 h-5" />
                <h2 className="text-lg font-semibold">Filtros</h2>
              </div>

              {/* Search */}
              <div className="mb-6">
                <label className="block text-sm font-medium mb-2">Buscar</label>
                <input
                  type="text"
                  placeholder="Nome do jogo..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Categories */}
              <div>
                <label className="block text-sm font-medium mb-3">Categorias</label>
                <div className="space-y-2">
                  <button
                    onClick={() => setSelectedCategory('')}
                    className={`w-full text-left px-3 py-2 rounded-lg transition ${
                      !selectedCategory
                        ? 'bg-blue-100 text-blue-700 font-medium'
                        : 'hover:bg-gray-100'
                    }`}
                  >
                    Todas
                  </button>
                  {categories.map((category) => (
                    <button
                      key={category}
                      onClick={() => setSelectedCategory(category)}
                      className={`w-full text-left px-3 py-2 rounded-lg transition ${
                        selectedCategory === category
                          ? 'bg-blue-100 text-blue-700 font-medium'
                          : 'hover:bg-gray-100'
                      }`}
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Main Content - Products */}
          <div className="lg:col-span-3">
            {loading ? (
              <div className="text-center py-12">
                <p className="text-gray-600">Carregando produtos...</p>
              </div>
            ) : products.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-600 mb-4">Nenhum produto disponível.</p>
                <p className="text-sm text-gray-500">Certifique-se de que a API está rodando em {API_ENDPOINTS.PRODUCTS}</p>
              </div>
            ) : (
              <>
                <p className="text-gray-600 mb-6">
                  Mostrando {filteredProducts.length} de {products.length} produtos
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredProducts.map((product) => (
                    <Link key={product.id} href={`/products/${product.id}`}>
                      <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition overflow-hidden cursor-pointer h-full flex flex-col">
                        <div className="bg-gray-200 h-48 flex items-center justify-center">
                          <Gamepad2 className="w-16 h-16 text-gray-400" />
                        </div>
                        <div className="p-4 flex-1 flex flex-col">
                          <h3 className="font-semibold text-lg mb-2 line-clamp-2 flex-1">{product.nome}</h3>
                          <div className="flex justify-between items-center mb-3">
                            <span className="text-sm text-gray-600">{product.categoria}</span>
                            <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                              {product.plataforma}
                            </span>
                          </div>
                          <div className="flex justify-between items-center pt-3 border-t">
                            <span className="text-2xl font-bold text-blue-600">
                              R$ {product.preco.toFixed(2)}
                            </span>
                            <Button size="sm">Comprar</Button>
                          </div>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
                {filteredProducts.length === 0 && (
                  <div className="text-center py-12">
                    <p className="text-gray-600">Nenhum produto encontrado.</p>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
