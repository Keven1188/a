import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Trash2, ArrowLeft, ShoppingCart } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { useState } from 'react';
import { toast } from 'sonner';

export default function Cart() {
  const { items, removeItem, updateQuantity, total, clearCart } = useCart();
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  const handleCheckout = async () => {
    if (items.length === 0) {
      toast.error('Carrinho vazio');
      return;
    }

    setIsCheckingOut(true);
    try {
      // Simular checkout
      await new Promise((resolve) => setTimeout(resolve, 1000));
      toast.success('Pedido realizado com sucesso!');
      clearCart();
      // Redirect to orders page would happen here
    } catch (error) {
      toast.error('Erro ao processar pedido');
    } finally {
      setIsCheckingOut(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <Link href="/products">
            <Button variant="outline" className="mb-8">
              <ArrowLeft className="mr-2 w-4 h-4" />
              Voltar ao Catálogo
            </Button>
          </Link>

          <div className="bg-white rounded-lg shadow-md p-12 text-center">
            <ShoppingCart className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h1 className="text-2xl font-bold mb-4">Seu carrinho está vazio</h1>
            <p className="text-gray-600 mb-8">Adicione alguns jogos para começar suas compras!</p>
            <Link href="/products">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                Explorar Catálogo
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <Link href="/products">
          <Button variant="outline" className="mb-8">
            <ArrowLeft className="mr-2 w-4 h-4" />
            Voltar ao Catálogo
          </Button>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6 border-b">
                <h1 className="text-2xl font-bold">Carrinho de Compras</h1>
                <p className="text-gray-600">{items.length} item(ns)</p>
              </div>

              <div className="divide-y">
                {items.map((item) => (
                  <div key={item.id} className="p-6 flex gap-4 hover:bg-gray-50 transition">
                    <div className="w-20 h-20 bg-gray-200 rounded-lg flex items-center justify-center flex-shrink-0">
                      <ShoppingCart className="w-8 h-8 text-gray-400" />
                    </div>

                    <div className="flex-1">
                      <h3 className="font-semibold text-lg mb-1">{item.nome}</h3>
                      <p className="text-blue-600 font-bold">R$ {item.preco.toFixed(2)}</p>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="flex items-center border border-gray-300 rounded-lg">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantidade - 1)}
                          className="px-3 py-1 hover:bg-gray-100"
                        >
                          -
                        </button>
                        <span className="px-3 py-1 font-semibold">{item.quantidade}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantidade + 1)}
                          className="px-3 py-1 hover:bg-gray-100"
                        >
                          +
                        </button>
                      </div>

                      <div className="text-right">
                        <p className="text-sm text-gray-600">Subtotal</p>
                        <p className="font-bold">R$ {(item.preco * item.quantidade).toFixed(2)}</p>
                      </div>

                      <button
                        onClick={() => removeItem(item.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-24">
              <h2 className="text-xl font-bold mb-6">Resumo do Pedido</h2>

              <div className="space-y-4 mb-6">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span>R$ {total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Frete</span>
                  <span>Grátis</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Desconto</span>
                  <span className="text-green-600">R$ 0,00</span>
                </div>
                <div className="border-t pt-4 flex justify-between">
                  <span className="font-bold">Total</span>
                  <span className="text-2xl font-bold text-blue-600">R$ {total.toFixed(2)}</span>
                </div>
              </div>

              <Button
                size="lg"
                className="w-full bg-blue-600 hover:bg-blue-700 mb-3"
                onClick={handleCheckout}
                disabled={isCheckingOut}
              >
                {isCheckingOut ? 'Processando...' : 'Finalizar Compra'}
              </Button>

              <Button
                size="sm"
                variant="outline"
                className="w-full"
                onClick={() => clearCart()}
              >
                Limpar Carrinho
              </Button>

              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-gray-600">
                  ✓ Compra segura com criptografia SSL
                </p>
                <p className="text-sm text-gray-600 mt-2">
                  ✓ Entrega instantânea de jogos digitais
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
